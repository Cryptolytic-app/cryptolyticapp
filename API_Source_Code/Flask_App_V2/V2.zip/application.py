import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, render_template
import pickle
import datetime as dt
import glob
import boto3
from utils import create_conn, retrieve_data, credentials, retrieve_data2


application = Flask(__name__)


@application.route('/')
def index():
    """Homepage"""
    return render_template('index.html')


@application.route('/crypto', methods=['POST'])
def crypto_trade_predictions():
    """ Takes in data from crypto exchanges and returns an output for whether
        the model predicts the price of a coin will go up or down in the next
        1 hour period.

        Supported Exchange/Trading Pairs:
            - bitfinex
                - 'btc_usd'
                - 'eth_usd'
                - 'ltc_usd'
            - coinbase_pro
                - 'btc_usd'
                - 'eth_usd'
                - 'ltc_usd'
            - hitbtc
                - 'btc_usdt'
                - 'eth_usdt'
                - 'ltc_usdt'

        Sample request:
        post = { "exchange" : "bitfinex",
                 "trading_pair" : "btc_usd" }
        """

    # request data
    exchange = request.form.get('exchange')
    trading_pair = request.form.get('trading_pair')

    # HitBTC needs a t at the end for usd pairings
    if exchange == 'hitbtc':
        trading_pair = trading_pair + 't'

    predictions = retrieve_data(exchange, trading_pair)

    return render_template("result.html", results=predictions)


# Route for crypto trade recommender testing
@application.route('/testingtrp', methods=['POST'])
def crypto_trade_predictions_testing():

    # request data
    exchange_trading_pair = request.get_json(force=True)

    exchange = exchange_trading_pair['exchange']
    trading_pair = exchange_trading_pair['trading_pair']

    predictions = retrieve_data(exchange, trading_pair)
    return jsonify(results=predictions)

# Route for arbritage prediction
@application.route('/arb', methods=['POST'])
def arbritage_predictions():

    exchange_1 = request.form.get('exchange_1')
    exchange_2 = request.form.get('exchange_2')
    trading_pair = request.form.get('trading_pair')

    if exchange_1 == 'hitbtc':
        if trading_pair.split('_')[1] == 'usd':
            trading_pair = trading_pair + 't'
    if exchange_2 == 'hitbtc':
        if trading_pair.split('_')[1] == 'usd':
            trading_pair = trading_pair + 't'

    predictions = retrieve_data2(exchange_1, exchange_2, trading_pair)
    try:
        return render_template("resultarb.html", results=predictions)
    except:
        return render_template('error.html')


# Route for arbritage testing
@application.route('/testingarb', methods=['POST'])
def arbritage_predictions_testing():

    exchange_trading_pair = request.get_json(force=True)
    exchange_1 = exchange_trading_pair['exchange_1']
    exchange_2 = exchange_trading_pair['exchange_2']
    trading_pair = exchange_trading_pair['trading_pair']

    predictions = retrieve_data2(exchange_1, exchange_2, trading_pair)
    return jsonify(results=predictions)


if __name__ == '__main__':
    application.run(port=3000, debug=True)
