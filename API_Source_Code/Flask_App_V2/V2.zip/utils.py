import pandas as pd
import psycopg2 as ps

# from config import aws_access_key_id, aws_secret_access_key, POSTGRES_DBNAME, POSTGRES_PASSWORD, POSTGRES_USERNAME, POSTGRES_PORT, POSTGRES_ADDRESS

""" Functions for Flask App"""


# New DB
credentials = {'POSTGRES_ADDRESS': '',
               'POSTGRES_PORT': '',
               'POSTGRES_USERNAME': '',
               'POSTGRES_PASSWORD': '',
               'POSTGRES_DBNAME': '',
               'API_KEY': ''}


# Database connection
def create_conn(credentials):

    conn = ps.connect(host=credentials['POSTGRES_ADDRESS'],
                      database=credentials['POSTGRES_DBNAME'],
                      user=credentials['POSTGRES_USERNAME'],
                      password=credentials['POSTGRES_PASSWORD'],
                      port=credentials['POSTGRES_PORT'])

    cur = conn.cursor()
    return conn, cur

# This is for retrieving trade recommender predicitons from DB
def retrieve_data(exchange, trading_pair):

    # create connection and cursor
    conn, cur = create_conn(credentials)

    # Change limit number to whatever amount of rows you want to retrieve
    cur.execute("""SELECT * FROM prediction.trp
                    WHERE exchange = '{exchange}'
                    AND trading_pair = '{trading_pair}'
                    ORDER by p_time desc limit 1;""".format(trading_pair=trading_pair, exchange=exchange))

    result = cur.fetchall()

    result = pd.DataFrame(result)

    result = result.rename(
        columns={0: 'p_time', 1: 'c_time', 2: 'exchange', 3: 'trading_pair', 4: 'prediction'})

    result = result.to_dict()

    conn.close()

    return result


# This is for retrieving arbitrage predictions from DB
def retrieve_data2(exchange_1, exchange_2, trading_pair):

    # create connection and cursor
    conn, cur = create_conn(credentials)

    try:
        cur.execute("""SELECT * FROM prediction.arp
                    WHERE exchange_1 = '{exchange_2}'
                    AND exchange_2 = '{exchange_1}'
                    AND trading_pair = '{trading_pair}'
                    OR exchange_1 = '{exchange_1}'
                    AND exchange_2 = '{exchange_2}'
                    AND trading_pair = '{trading_pair}'
                    ORDER by p_time desc limit 1;""".format(trading_pair=trading_pair, exchange_2=exchange_2, exchange_1=exchange_1))

        result = cur.fetchall()

        result = pd.DataFrame(result)

        result = result.rename(
            columns={0: 'p_time', 1: 'c_time', 2: 'exchange_1', 3: 'exchange_2', 4: 'trading_pair', 5: 'prediction'})

        result = result.to_dict()

        conn.close()

        return result

    except:
        pass
